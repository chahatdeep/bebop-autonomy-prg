
"use strict";

let SetPose = require('./SetPose.js')

module.exports = {
  SetPose: SetPose,
};
